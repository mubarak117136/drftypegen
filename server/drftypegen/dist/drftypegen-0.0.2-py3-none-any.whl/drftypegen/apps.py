from django.apps import AppConfig


class DrftypegenConfig(AppConfig):
    name = 'drftypegen'
